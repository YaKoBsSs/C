//fgetc() ile dosyadaki metni teker teker karakter olarak okuma ve içeriği görüntüleme.
#include <stdio.h>
#include <stdlib.h>
int main()
{
    FILE * fPtr;
    char karakter;
    fPtr=fopen("file1.txt", "r");
    if(fPtr==NULL){
        printf("Dosya okunamadı.\n");
        exit(EXIT_FAILURE);
    }
    printf("Dosya başarıyla açıldı, içeriği okunuyor...\n");
    do{
    //Dosyadan bir karakter oku.
    karakter=fgetc(fPtr);
    //Dosyadan okunan karakteri konsola yazdır.
    putchar(karakter);
    //End of file(EOF) karakterine denk gelmediğin sürece yap.
    }while(karakter!=EOF);
    fclose(fPtr);
    return 0;
}
