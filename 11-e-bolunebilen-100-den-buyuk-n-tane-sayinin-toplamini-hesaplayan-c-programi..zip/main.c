#include <stdio.h>
/*11'e bölünebilen 100'den büyük n tane sayının toplamını hesaplayan c programı*/
int main()
{
    int sayi, sayac=0, toplam=0, n;
    printf("100'den büyük n tane sayı giriniz:\n");
    printf("n'i giriniz:\n");
    scanf("%d", &n);
    for(sayac=0;sayac<n;sayac++)
    {
        scanf("%d", &sayi);
        if(sayi<101)
        {
            printf("100'den küçük veya eşit bir sayı girdiniz!\n");
            sayac-=1;
        }
        else
        {
            if(sayi%11==0)
            {
                toplam+=sayi;
            }
        }
    }
    printf("Toplam =" "%d", toplam);
    return 0;
}




























