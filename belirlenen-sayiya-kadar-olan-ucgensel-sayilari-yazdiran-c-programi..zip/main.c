#include <stdio.h>
// Belirlenen sayıya kadar olan üçgensel sayıları yazdıran c programı.
int n = 1, ust_sinir, r=1;
int main(){
    printf("Lütfen bir üst sınır giriniz.");
    scanf("%d", &ust_sinir);
    if(ust_sinir<2){
        printf("Lütfen 1'den büyük pozitif bir tam sayı giriniz.");
    }
    for(n; n<ust_sinir; n+=r){
    printf("%d\n", n);
    r++;    
    if(n>ust_sinir){
        return 0;
    }
    }
}
