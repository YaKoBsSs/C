#include <stdio.h>
#include <math.h>
//n dereceli iki değişkenli bir polinomun açılımını yapan c programı.
int xk, yk, derece, n, r, ilk_derece, per;
char x, y;
int faktoriyel_al(int n) {
    int fak = 1;
    for (n; n > 1; n--) {
        fak *= n;
    }
    return fak;
}
int permutasyon_al(int n, int r) {
    per = faktoriyel_al(n) / (faktoriyel_al(n - r) * faktoriyel_al(r));
    return per;
}

int main() {
    printf("x'in katsayısını giriniz.");
    scanf("%d", &xk);
    printf("y'nin katsayısını giriniz.");
    scanf("%d", &yk);
    printf("dereceyi giriniz.");
    scanf("%d", &derece);
    //Eğer derece negatifse pay'da 1 varken yazdırdık.
    if(derece<0){
    printf("1/(");
    derece *= -1;
    ilk_derece=derece;
    for (derece; derece >= 0; derece--) {
        printf("%d", permutasyon_al(ilk_derece, ilk_derece-derece));
        if(derece>0){
            if(xk<0&&derece%2==0){
                printf("*%dx^%d", (-1*xk), derece);
            }
            else{
            printf("*%dx^%d", xk, derece);
        }}
        if(ilk_derece-derece>0){
            if(yk<0&&(ilk_derece-derece)%2==0){
                printf("*%dy^%d", (-1*yk), ilk_derece-derece);
            }
            else{
            printf("*%dy^%d", yk, ilk_derece-derece);
        }}
        if(derece>0){
            printf("+");
        }
    }
    printf(")");
    return 0;
}
    ilk_derece=derece;
    //derecenin her değeri için binom açılımı yaptık,
    //Eğer katsayılardan biri negatif ama derecesi pozitifse sayıyı pozitif yazdırdık.
    for (derece; derece >= 0; derece--) {
        printf("%d", permutasyon_al(ilk_derece, ilk_derece-derece));
        if(derece>0){
            if(xk<0&&(derece%2)==0){
                printf("*%dx^%d", (-1*xk), derece);
            }
            else{
            printf("*%dx^%d", xk, derece);
        }}
        if(ilk_derece-derece>0){
            if(yk<0&&(ilk_derece-derece)%2==0){
                printf("*%dy^%d", (-1*yk), ilk_derece-derece);
            }
            else{
            printf("*%dy^%d", yk, ilk_derece-derece);
        }}
        if(derece>0){
            printf("+");
        }
    }
    return 0;
}






















