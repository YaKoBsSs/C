#include <stdio.h>
//Belirlenen sayıya kadar olan karesel sayıları yazan c programı.
int n=1, ust_sinir; 
int main(){
    printf("Lütfen üst sınırı giriniz.");
    scanf("%d", &ust_sinir);
    for(n; n*n<ust_sinir; n++){
    printf("%d\n", n*n);
}
    return 0;
}
