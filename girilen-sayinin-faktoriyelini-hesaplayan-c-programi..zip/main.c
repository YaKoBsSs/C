#include <stdio.h>
//Girilen sayının faktöriyelini hesaplayan c programı.
int main()
{
    int sayi, i;
   printf("Faktöriyeli hesaplanacak olan tam sayıyı giriniz.");
   scanf("%d", &sayi);
   if(sayi<0){
       printf("Lütfen negatif bir tam sayı girmeyiniz");
   }
   else if(sayi<=1){
       printf("Girilen tam sayının faktöriyeli = 1");
   }
   else{
   for(i=sayi-1;i>1;i--){
       sayi*=i;
   }
   printf("Girilen tam sayının faktöriyeli = %d\n", sayi);
}
    return 0;
}
