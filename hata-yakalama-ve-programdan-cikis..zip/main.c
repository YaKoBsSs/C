//Hata yakalama ve programdan çıkış.
#include <stdio.h>
#include <stdlib.h>
int bolunen, bolen, bolum;
int main()
{
    printf("Bölünen ve bölen tam sayılarını giriniz.;");
    scanf("%d%d", &bolunen, &bolen);
    if(bolen == 0){
        fprintf(stderr, "Sıfıra bölme hatası! programdan çıkılıyor...\n");
        exit(-1);//exit(EXIT_FAILURE);
    }
    bolum=bolunen / bolen;
    fprintf(stderr, "Sonuc = %d", bolum);
    exit(0); //exit(EXIT_SUCCESS);
    return 0;
}
