//Dosya oluşturma ve yazma.
#include <stdio.h>
#include <stdlib.h>
//1000 karakterlik bir değişken tanımlıyoruz.
#define VERI_BOYUTU 1000
int main(){
//Veri boyutunu depolayan karakter dizisi.
char veri[VERI_BOYUTU];
//Dosyaya işaret edebilmek için dosya işaretçisi tanımladık.
FILE * fPtr;
//Dosyayı w(write), R(Read), A(Appent), +(Bir şeyler ekleme).
//data/file1.txt diye bir dosya varsa ona erişir, yoksa data diye bir dizin oluşturup onun altında file1.txt diye bir dosya oluşturur.
fPtr = fopen("file1.txt", "w+");
if(fPtr==NULL){
printf("Dosya oluşturulamadı.\n");
//Dosya oluşturulamadığı için programdan çıktık.
exit(EXIT_FAILURE);}
printf("Dosyaya kaydedilecek olan metni yazınız.\n");
//File get string komutuyla dosyaya kaydedilecek olan metni "veri" dizisinin içine at, "VERI_BOYUTU" boyutunda ve "standart input" olarak al.
fgets(veri, VERI_BOYUTU, stdin);
//File put string komutuyla veri dizisinin içine atılan metni dosyaya yaz.
fputs(veri, fPtr);
//File close komutuyla dosyayı kapattık.
fclose(fPtr);
printf("Metin, dosyaya başarılı bir şekilde kaydedildi.");
return 0;}