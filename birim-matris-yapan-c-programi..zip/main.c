#include <stdio.h>
//by enes, yakub. Birim matris yapan c programı.
int a[5][5], i, j;
int main(){
    for(i=0;i<5;i++){
        for(j=0;j<5;j++){
            if(i==j)
                a[i][j]=1;
            else
                a[i][j]=0;
                 printf("%d ", a[i][j]);
        }
        printf("\n");
    }
    return 0;
}
