#include <stdio.h>
/*Belirlenen fonlsiyonun değerini verilen x ve y değerlerine göre hesaplayan c programı*/
int main()
{
  int x, y, toplam=0, sayac=1;
  printf("Lütfen x ve y değerlerini giriniz.\n");
  scanf("%d%d", &x, &y);
  for(sayac=1;sayac<6;sayac++)
  {
      toplam*=((3*x)/sayac)+(y*y);
  }
  for(sayac=6;sayac<16;sayac++)
  {
      toplam+=(x/sayac)+(2*y);
  }
  printf("Fonksiyonun değeri =%d", toplam);
}
