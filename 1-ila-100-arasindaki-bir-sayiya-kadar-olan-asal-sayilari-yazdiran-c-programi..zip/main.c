#include <stdio.h>
// 1 ilâ 100 arasında seçilen bir sayıya kadar olan tüm asal sayıları yazdıran c programı.
int ust_deger, sayi, sayac;
int main(){
    printf("1 ilâ 100 arasında bir sayı giriniz.");
    scanf("%d", &ust_deger);
    if(ust_deger<1 || ust_deger>100){
        printf("Lütfen 1 ilâ 100 arasında olan bir sayı giriniz.");
        return 0;
    }
    if(ust_deger<=2){
        printf("Asal sayı yok");
    }
    if(ust_deger==3){
        printf("2");
    }
    if(ust_deger==4){
        printf("2\n3");
    }
    if(ust_deger==5){
        printf("2\n3");
    }
    printf("2\n3");
    for(sayi=5;sayi<ust_deger;sayi+=2){
        for(sayac=2;sayac<=sayi/2;sayac++){
            if(sayi%sayac==0){
                break;
            }
        }
    if(sayac>sayi/2){
        printf("\n%d", sayi);
    }}
    return 0;
}

























